// JavaScript Document


document.write("<aside>");
showCmdURL();
document.write("</aside>");


		