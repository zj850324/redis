// JavaScript Document
var footHTML = "";
footHTML += '<footer>';
footHTML += '     <div class="sponsor">';
footHTML += '        本站资源翻译自<a href="http://redis.io" target="_blank">redis.io</a>，由<a href="/aboutus.html">redis.cn翻译团队</a>，更新日志请点击<a href="/update.html">这里</a>查看，翻译原文版权归redis.io官方所有，翻译不正确的地方欢迎大家指出。<br/>';
footHTML += '        联系Email:<a href="mailto:admin@redis.cn">admin@redis.cn</a>，redis交流群：<a href="#">46859267</a> &nbsp; ';
footHTML += "<scr";
footHTML += "ipt src='http://s22.cnzz.com/stat.php?id=3593514&web_id=3593514' langu";
footHTML += "age='JavaScript'></scr";
footHTML += "ipt>";
footHTML += '      </div>';
footHTML += '    </footer>';
	
document.write(footHTML);

