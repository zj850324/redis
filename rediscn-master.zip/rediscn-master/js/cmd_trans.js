// JavaScript Document



document.write("<h2>相关主题</h2>");
document.write("          <ul>");
document.write("            <li><a href='/topics/transactions.html'>事务</a></li>");
document.write("          </ul>");

		