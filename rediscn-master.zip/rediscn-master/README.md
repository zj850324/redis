rediscn
=======

redis api中文翻译
